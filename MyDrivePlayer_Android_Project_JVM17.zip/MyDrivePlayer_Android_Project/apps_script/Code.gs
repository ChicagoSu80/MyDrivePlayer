const FOLDER_ID = "1XkQlz4Ygu3HbYxPYGZrKHxKnYRtfCiKW";

function doGet(e) {
  if (e && e.parameter && e.parameter.action === "tracks") {
    return ContentService
      .createTextOutput(JSON.stringify(getTracks()))
      .setMimeType(ContentService.MimeType.JSON);
  }

  return HtmlService.createHtmlOutput(
    "<h2>My Drive Player API</h2><p>Servizio attivo.</p>"
  );
}

function getTracks() {
  const folder = DriveApp.getFolderById(FOLDER_ID);
  const files = folder.getFiles();
  const tracks = [];
  const audioExt = /\.(mp3|m4a|aac|wav|ogg|oga|flac|aiff|aif|wma)$/i;

  while (files.hasNext()) {
    const file = files.next();
    const name = file.getName();
    const mime = file.getMimeType() || "";

    if (/^audio\//i.test(mime) || audioExt.test(name)) {
      tracks.push({
        id: file.getId(),
        name: name,
        url: "https://drive.google.com/uc?export=download&id=" +
          encodeURIComponent(file.getId())
      });
    }
  }

  tracks.sort((a, b) => a.name.localeCompare(b.name, "it"));
  return tracks;
}
