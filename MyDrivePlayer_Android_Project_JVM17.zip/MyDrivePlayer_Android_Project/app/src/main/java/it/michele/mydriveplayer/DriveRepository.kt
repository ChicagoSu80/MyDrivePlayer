package it.michele.mydriveplayer

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

object DriveRepository {
    // Inserisci qui l'URL della distribuzione Web App di Apps Script.
    // Deve terminare con /exec (senza ?action=tracks).
    const val API_URL = "https://script.google.com/macros/s/AKfycbxQP593k0KBdChQynTLbayQbVqH9I0DRw55a3sisJmiaiyEXXI7RhjYSAPGrRCCju1Z/exec"

    fun loadTracks(): List<Track> {
        require(API_URL.startsWith("https://") && !API_URL.startsWith("INCOLLA")) {
            "Configura prima API_URL in DriveRepository.kt"
        }

        val url = URL("$API_URL?action=tracks")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20000
            readTimeout = 30000
            setRequestProperty("Accept", "application/json")
        }

        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) error("Risposta server HTTP $code: $body")

            val json = JSONArray(body)
            return buildList {
                for (i in 0 until json.length()) {
                    val item = json.getJSONObject(i)
                    add(
                        Track(
                            id = item.getString("id"),
                            name = item.getString("name"),
                            url = item.getString("url")
                        )
                    )
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
