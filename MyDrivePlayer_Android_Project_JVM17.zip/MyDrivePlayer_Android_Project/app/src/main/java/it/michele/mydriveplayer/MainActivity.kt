package it.michele.mydriveplayer

import android.content.ComponentName
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private val tracks = mutableListOf<Track>()
    private lateinit var status: TextView
    private lateinit var nowPlaying: TextView
    private lateinit var playlist: LinearLayout
    private lateinit var playButton: Button

    private val bg = Color.rgb(16, 19, 26)
    private val panel = Color.rgb(27, 34, 48)
    private val accent = Color.rgb(139, 156, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(170, 180, 197)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        connectPlayer()
        refreshTracks()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(bg)
        }

        val heading = TextView(this).apply {
            text = "MY DRIVE PLAYER"
            textSize = 22f
            setTextColor(white)
            letterSpacing = .08f
        }
        root.addView(heading)

        val subtitle = TextView(this).apply {
            text = "La tua musica, direttamente da Google Drive"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 6, 0, 22)
        }
        root.addView(subtitle)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(22, 24, 22, 22)
            setBackgroundColor(panel)
        }
        root.addView(card, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val disc = TextView(this).apply {
            text = "♫"
            textSize = 64f
            gravity = Gravity.CENTER
            setTextColor(accent)
        }
        card.addView(disc)

        nowPlaying = TextView(this).apply {
            text = "Seleziona una traccia"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(white)
            setPadding(0, 10, 0, 4)
        }
        card.addView(nowPlaying)

        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 6)
        }
        card.addView(controls)

        val previous = makeButton("⏮")
        playButton = makeButton("▶")
        val next = makeButton("⏭")
        controls.addView(previous)
        controls.addView(playButton)
        controls.addView(next)

        previous.setOnClickListener { player?.seekToPreviousMediaItem() }
        next.setOnClickListener { player?.seekToNextMediaItem() }
        playButton.setOnClickListener {
            player?.let { p ->
                if (p.isPlaying) p.pause() else p.play()
            }
        }

        val options = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 0)
        }
        card.addView(options)
        val shuffle = makeButton("🔀")
        val repeat = makeButton("↻")
        options.addView(shuffle)
        options.addView(repeat)
        shuffle.setOnClickListener {
            player?.shuffleModeEnabled = !(player?.shuffleModeEnabled ?: false)
            Toast.makeText(this, if (player?.shuffleModeEnabled == true) "Casuale attivo" else "Casuale disattivato", Toast.LENGTH_SHORT).show()
        }
        repeat.setOnClickListener {
            player?.repeatMode = if (player?.repeatMode == Player.REPEAT_MODE_ALL) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ALL
            Toast.makeText(this, if (player?.repeatMode == Player.REPEAT_MODE_ALL) "Ripeti playlist" else "Ripetizione disattivata", Toast.LENGTH_SHORT).show()
        }

        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 20, 0, 8)
        }
        root.addView(row)
        val label = TextView(this).apply {
            text = "Playlist"
            textSize = 18f
            setTextColor(white)
        }
        row.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val refresh = makeButton("↻ Aggiorna")
        row.addView(refresh)
        refresh.setOnClickListener { refreshTracks() }

        status = TextView(this).apply {
            text = "Connessione alla raccolta…"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 0, 0, 10)
        }
        root.addView(status)

        val scroll = ScrollView(this)
        playlist = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(playlist)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    private fun makeButton(label: String): Button =
        Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setTextColor(white)
            backgroundTintList = ContextCompat.getColorStateList(this@MainActivity, android.R.color.darker_gray)
        }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                player = controllerFuture?.get()
                player?.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        playButton.text = if (isPlaying) "Ⅱ" else "▶"
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        nowPlaying.text = mediaItem?.mediaMetadata?.title ?: "Nessuna traccia"
                    }
                })
            } catch (e: Exception) {
                status.text = "Errore lettore: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun refreshTracks() {
        status.text = "Lettura della cartella Drive…"
        executor.execute {
            try {
                val loaded = DriveRepository.loadTracks()
                runOnUiThread {
                    tracks.clear()
                    tracks.addAll(loaded)
                    playlist.removeAllViews()
                    loaded.forEachIndexed { index, track ->
                        val button = TextView(this).apply {
                            text = "${index + 1}.  ${track.name}"
                            textSize = 15f
                            setTextColor(white)
                            setPadding(14, 18, 14, 18)
                            setBackgroundColor(panel)
                            isClickable = true
                            setOnClickListener { playTrack(index) }
                        }
                        val params = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        params.bottomMargin = 2
                        playlist.addView(button, params)
                    }
                    status.text = if (loaded.isEmpty()) {
                        "Nessun file audio trovato."
                    } else {
                        "${loaded.size} tracce disponibili"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Errore: ${e.message ?: "impossibile leggere la playlist"}"
                }
            }
        }
    }

    private fun playTrack(index: Int) {
        val p = player ?: run {
            Toast.makeText(this, "Lettore in avvio, riprova tra un istante", Toast.LENGTH_SHORT).show()
            return
        }
        val items = tracks.map { track ->
            MediaItem.Builder()
                .setUri(track.url)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(track.name).build())
                .build()
        }
        p.setMediaItems(items, index, 0L)
        p.prepare()
        p.play()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        executor.shutdown()
        super.onDestroy()
    }
}
