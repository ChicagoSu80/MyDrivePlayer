package it.michele.mydriveplayer

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ComponentName
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private val tracks = mutableListOf<Track>()
    private lateinit var status: TextView
    private lateinit var nowPlaying: TextView
    private lateinit var playlist: LinearLayout
    private lateinit var playButton: Button
    private lateinit var vinyl: VinylView
    private var spinAnimator: ObjectAnimator? = null

    private val bg = Color.rgb(20, 20, 19)
    private val panel = Color.rgb(38, 37, 33)
    private val panel2 = Color.rgb(49, 46, 39)
    private val accent = Color.rgb(255, 173, 66)
    private val cream = Color.rgb(245, 232, 204)
    private val muted = Color.rgb(174, 163, 140)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        connectPlayer()
        refreshTracks()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif-condensed", Typeface.BOLD)
                      else Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(26))
        }
        scroll.addView(root)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("MY DRIVE PLAYER", 24f, cream, true))
        brand.addView(text("THE SOUND OF YOUR DRIVE", 10f, accent, true).apply { letterSpacing = .18f })
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(text("●  STEREO", 11f, accent, true))
        root.addView(top)
        root.addView(text("YOUR PERSONAL MUSIC MACHINE", 11f, muted, true).apply {
            letterSpacing = .12f
            setPadding(0, dp(7), 0, dp(20))
        })

        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(22), dp(20), dp(20))
            background = rounded(panel, 24, Color.rgb(83, 70, 48))
        }
        root.addView(playerCard, LinearLayout.LayoutParams(-1, -2))
        playerCard.addView(text("NOW SPINNING", 11f, accent, true).apply { letterSpacing = .2f })
        vinyl = VinylView(this)
        playerCard.addView(vinyl, LinearLayout.LayoutParams(dp(206), dp(206)).apply {
            topMargin = dp(14); bottomMargin = dp(12)
        })
        nowPlaying = text("SCEGLI UN BRANO", 20f, cream, true).apply {
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(4), dp(4), dp(4), 0)
        }
        playerCard.addView(nowPlaying, LinearLayout.LayoutParams(-1, -2))
        playerCard.addView(text("GOOGLE DRIVE COLLECTION", 10f, muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = .12f
            setPadding(0, dp(5), 0, dp(14))
        })

        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        val previous = makeButton("|◀", false)
        playButton = makeButton("▶", true)
        val next = makeButton("▶|", false)
        controls.addView(previous, LinearLayout.LayoutParams(dp(62), dp(52)).apply { marginEnd = dp(12) })
        controls.addView(playButton, LinearLayout.LayoutParams(dp(76), dp(58)))
        controls.addView(next, LinearLayout.LayoutParams(dp(62), dp(52)).apply { marginStart = dp(12) })
        playerCard.addView(controls)
        previous.setOnClickListener { player?.seekToPreviousMediaItem() }
        next.setOnClickListener { player?.seekToNextMediaItem() }
        playButton.setOnClickListener { player?.let { p -> if (p.isPlaying) p.pause() else p.play() } }

        val options = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }
        val shuffle = makeButton("⤨  SHUFFLE", false)
        val repeat = makeButton("↻  REPEAT", false)
        options.addView(shuffle, LinearLayout.LayoutParams(-2, dp(40)).apply { marginEnd = dp(8) })
        options.addView(repeat, LinearLayout.LayoutParams(-2, dp(40)))
        playerCard.addView(options)
        shuffle.setOnClickListener {
            player?.shuffleModeEnabled = !(player?.shuffleModeEnabled ?: false)
            Toast.makeText(this, if (player?.shuffleModeEnabled == true) "Casuale attivo" else "Casuale disattivato", Toast.LENGTH_SHORT).show()
        }
        repeat.setOnClickListener {
            player?.repeatMode = if (player?.repeatMode == Player.REPEAT_MODE_ALL) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ALL
            Toast.makeText(this, if (player?.repeatMode == Player.REPEAT_MODE_ALL) "Ripeti playlist" else "Ripetizione disattivata", Toast.LENGTH_SHORT).show()
        }

        val section = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(24), 0, dp(8))
        }
        section.addView(text("SIDE A  /  PLAYLIST", 17f, cream, true), LinearLayout.LayoutParams(0, -2, 1f))
        val refresh = makeButton("↻", false)
        section.addView(refresh, LinearLayout.LayoutParams(dp(48), dp(42)))
        refresh.setOnClickListener { refreshTracks() }
        root.addView(section)
        status = text("RICERCA DEI BRANI…", 11f, muted, true).apply { setPadding(0, 0, 0, dp(10)) }
        root.addView(status)
        playlist = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(playlist)
        root.addView(text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━", 12f, accent).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(4))
        })
        root.addView(text("MADE FOR MUSIC LOVERS  •  DRIVE EDITION", 10f, muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = .08f
        })
        setContentView(outer)
    }

    private fun makeButton(label: String, primary: Boolean): Button = Button(this).apply {
        text = label
        textSize = if (primary) 23f else 14f
        isAllCaps = false
        setTextColor(if (primary) bg else cream)
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        background = rounded(if (primary) accent else panel2, 16, if (primary) accent else Color.rgb(94, 79, 54))
        stateListAnimator = null
        elevation = dp(2).toFloat()
        if (!primary) setPadding(dp(8), 0, dp(8), 0)
    }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                player = controllerFuture?.get()
                player?.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        playButton.text = if (isPlaying) "Ⅱ" else "▶"
                        if (isPlaying) {
                            if (spinAnimator == null) {
                                spinAnimator = ObjectAnimator.ofFloat(vinyl, View.ROTATION, 0f, 360f).apply {
                                    duration = 7000
                                    repeatCount = ValueAnimator.INFINITE
                                    interpolator = android.view.animation.LinearInterpolator()
                                }
                            }
                            if (spinAnimator?.isStarted != true) spinAnimator?.start()
                        } else {
                            spinAnimator?.pause()
                        }
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        nowPlaying.text = mediaItem?.mediaMetadata?.title ?: "NESSUNA TRACCIA"
                    }
                })
            } catch (e: Exception) {
                status.text = "ERRORE LETTORE: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun refreshTracks() {
        status.text = "RICERCA DEI BRANI SU DRIVE…"
        executor.execute {
            try {
                val loaded = DriveRepository.loadTracks()
                runOnUiThread {
                    tracks.clear()
                    tracks.addAll(loaded)
                    playlist.removeAllViews()
                    loaded.forEachIndexed { index, track ->
                        val row = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            setPadding(dp(14), dp(12), dp(12), dp(12))
                            background = rounded(if (index % 2 == 0) panel else Color.rgb(31, 31, 28), 13)
                            isClickable = true
                            isFocusable = true
                            setOnClickListener { playTrack(index) }
                        }
                        val number = text(String.format("%02d", index + 1), 13f, accent, true)
                        row.addView(number, LinearLayout.LayoutParams(dp(34), -2))
                        val title = text(track.name.substringBeforeLast('.', track.name), 15f, cream, true).apply {
                            maxLines = 2
                            ellipsize = android.text.TextUtils.TruncateAt.END
                        }
                        row.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
                        row.addView(text("▶", 13f, accent, true).apply { setPadding(dp(8), 0, 0, 0) })
                        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
                        playlist.addView(row, params)
                    }
                    status.text = if (loaded.isEmpty()) "NESSUN FILE AUDIO TROVATO" else "${loaded.size} TRACCE DISPONIBILI  •  TOCCA PER ASCOLTARE"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "ERRORE: ${e.message ?: "IMPOSSIBILE LEGGERE LA PLAYLIST"}" }
            }
        }
    }

    private fun playTrack(index: Int) {
        val p = player ?: run {
            Toast.makeText(this, "Lettore in avvio, riprova tra un istante", Toast.LENGTH_SHORT).show()
            return
        }
        val items = tracks.map { track ->
            MediaItem.Builder().setUri(track.url)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(track.name).build()).build()
        }
        p.setMediaItems(items, index, 0L)
        p.prepare()
        p.play()
    }

    override fun onDestroy() {
        spinAnimator?.cancel()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        executor.shutdown()
        super.onDestroy()
    }

    private class VinylView(context: android.content.Context) : View(context) {
        private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
        private val groove = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.rgb(75, 70, 59)
        }
        var isSpinning = false
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val r = minOf(width, height) * .47f
            disc.color = Color.rgb(12, 12, 12)
            canvas.drawCircle(cx, cy, r, disc)
            for (fraction in floatArrayOf(.30f, .42f, .54f, .66f, .78f, .90f)) {
                canvas.drawCircle(cx, cy, r * fraction, groove)
            }
            disc.color = Color.rgb(185, 77, 39)
            canvas.drawCircle(cx, cy, r * .29f, disc)
            disc.color = Color.rgb(255, 183, 83)
            canvas.drawCircle(cx, cy, r * .055f, disc)
            disc.color = Color.rgb(240, 220, 183)
            disc.textSize = r * .10f
            disc.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            disc.textAlign = Paint.Align.CENTER
            canvas.drawText("MDP", cx, cy + r * .18f, disc)
        }
    }
}
