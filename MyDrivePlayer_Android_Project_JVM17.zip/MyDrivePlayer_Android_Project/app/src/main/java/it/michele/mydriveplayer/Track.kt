package it.michele.mydriveplayer

data class Track(
    val id: String,
    val name: String,
    val url: String
)
