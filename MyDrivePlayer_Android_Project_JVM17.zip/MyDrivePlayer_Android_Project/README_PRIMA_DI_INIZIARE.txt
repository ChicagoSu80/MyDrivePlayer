MY DRIVE PLAYER — PROGETTO ANDROID (SORGENTI)

Questo archivio contiene un progetto Android Studio iniziale e il servizio Google Apps Script.

IMPORTANTE
- Questo ZIP contiene il CODICE SORGENTE, non un APK già compilato.
- Per generare l'APK serve Android Studio con Android SDK/Gradle.
- La riproduzione diretta da Google Drive deve essere collaudata: Drive può mostrare pagine di conferma/download o applicare limiti di traffico. Non è un servizio CDN/streaming garantito.

PARTE A — SERVIZIO GOOGLE APPS SCRIPT
1. Apri il progetto Apps Script che hai già creato.
2. Sostituisci il contenuto di Code.gs con apps_script/Code.gs incluso in questo archivio.
3. Salva.
4. Distribuisci > Gestisci distribuzioni > Nuova distribuzione > App web.
5. Esegui come: Me (proprietario).
6. Accesso: Chiunque.
7. Distribuisci e autorizza Drive.
8. Copia l'URL che termina con /exec.

Il servizio esegue la lettura della cartella con i permessi del proprietario. L'endpoint ?action=tracks restituisce l'elenco dei file audio in JSON.

SICUREZZA
L'endpoint è pubblico: chiunque abbia l'URL può ottenere i nomi e gli URL dei file. I file stessi devono essere condivisi con "Chiunque abbia il link - Visualizzatore". Non inserire dati privati nella cartella.

PARTE B — ANDROID STUDIO
1. Scarica e installa Android Studio su un PC/Mac (non è realistico compilare questo progetto interamente dal telefono).
2. Estrai questo ZIP.
3. In Android Studio scegli Open e seleziona la cartella MyDrivePlayer_Android_Project.
4. Apri app/src/main/java/it/michele/mydriveplayer/DriveRepository.kt.
5. Sostituisci INCOLLA_QUI_URL_WEB_APP_APPS_SCRIPT con l'URL /exec ottenuto nella Parte A.
6. Attendi la sincronizzazione Gradle.
7. Collega un telefono Android con Debug USB oppure usa un emulatore.
8. Esegui l'app per testarla.
9. Per creare l'APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
10. Il file APK di debug si trova normalmente in app/build/outputs/apk/debug/app-debug.apk.

FUNZIONI NEL PROTOTIPO
- Elenco delle tracce recuperate da Drive
- Riproduzione, precedente/successiva
- Casuale e ripetizione playlist
- Servizio Media3 per riproduzione in background e controlli di sistema

LIMITI DA COLLAUDARE
- La gestione dei link di download di Google Drive e dello streaming/ripresa può variare in base a formato, dimensione, traffico e protezioni anti-abuso.
- Il prototipo non scarica copertine e non ha ancora barra di ricerca o gestione avanzata della cache.
- La playlist si aggiorna quando si preme Aggiorna; non c'è ancora un aggiornamento pianificato in background.
- Per un'app distribuita a molte persone, valutare un backend dedicato e un hosting audio/CDN, oltre alle condizioni d'uso e ai diritti sui brani.
